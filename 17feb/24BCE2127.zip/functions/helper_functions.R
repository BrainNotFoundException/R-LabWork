# Helper Functions
# Place your custom functions here

# Example function
hello_world <- function(name = "World") {
  cat(paste("Hello,", name, "!\n"))
}

# Add more functions as needed
