# R Programming Project

This is a beginner-friendly R project structure for statistical analysis and data science work.

## Project Structure

```
.
├── main.R                  # Main entry point for your R scripts
├── functions/              # Custom R functions
│   └── helper_functions.R  # Helper functions
├── scripts/                # Additional R scripts
├── data/                   # Input data files
├── output/                 # Output results and plots
└── README.md              # This file
```

## Prerequisites

You need to install R on your machine:

### On Ubuntu/Debian:
```bash
sudo apt-get update
sudo apt-get install r-base r-base-dev
```

### On macOS (with Homebrew):
```bash
brew install r
```

### On Windows:
Download and install from [https://cran.r-project.org/bin/windows/base/](https://cran.r-project.org/bin/windows/base/)

## Getting Started

### 1. Verify R Installation
```bash
R --version
```

### 2. Run the Main Script
```bash
Rscript main.R
```

### 3. Launch Interactive R Console
```bash
R
```

## VS Code Setup

### Install R Extensions
1. Open VS Code Extensions (Ctrl+Shift+X / Cmd+Shift+X)
2. Search for and install:
   - **R** (REditorSupport.r) - R language support and LSP
   - **R Debugger** (RDebugger.r-debugger) - Debugging support (optional)

### Run R Scripts from VS Code
- Press `Ctrl+Shift+B` (Cmd+Shift+B on Mac) to run `main.R`
- Or use the Command Palette (Ctrl+Shift+P) and select "Run Task"

## Installing R Packages

### From Command Line
```bash
R --vanilla --slave -e "install.packages('ggplot2')"
```

### Inside R Console
```r
install.packages("tidyverse")
install.packages("ggplot2")
install.packages("data.table")
```

## Example Workflow

1. Edit `main.R` to write your R code
2. Run `Rscript main.R` to execute your script
3. Store results in the `output/` directory
4. Place data files in the `data/` directory
5. Add reusable functions to `functions/helper_functions.R`

## Next Steps

- Modify `main.R` to start your analysis
- Add custom functions to `functions/helper_functions.R`
- Store data in `data/` directory
- Save results to `output/` directory

## Resources

- [R Project](https://www.r-project.org/)
- [R Documentation](https://www.r-project.org/other-docs.html)
- [RStudio Community](https://community.rstudio.com/)
- [Stack Overflow - R Tag](https://stackoverflow.com/questions/tagged/r)
