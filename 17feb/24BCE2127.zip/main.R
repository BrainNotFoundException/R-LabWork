# Main R Script
# This is your entry point for the R project

# Load functions
# source("functions/helper_functions.R")

# Load libraries (uncomment as needed)
# library(tidyverse)
# library(ggplot2)
# library(data.table)

# Your code here
cat("Hello from R!\n")
print(R.version$version.string)

# Example: Create and save data
df <- data.frame(x = 1:10, y = rnorm(10))
write.csv(df, "output/results.csv", row.names = FALSE)

x = 1:10
x_bar = mean(x)